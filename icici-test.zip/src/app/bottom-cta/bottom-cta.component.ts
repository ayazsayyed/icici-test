import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-cta',
  templateUrl: './bottom-cta.component.html',
  styleUrls: ['./bottom-cta.component.css']
})
export class BottomCtaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
